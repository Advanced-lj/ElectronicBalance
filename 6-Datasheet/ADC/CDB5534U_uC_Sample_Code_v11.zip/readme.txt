This 8051 microcontroller source is provided as an aid
in developing application code for the CS553x family of
ADCs.  It is not complete in that a copyrighted driver from
CYGNAL INTEGRATED PRODUCTS, INC is required for utilization
of the Silicon Labs C8051F320 microcontroller USB port.

This code is offered on an as is basis with no liability
on the part of Cirrus Logic.